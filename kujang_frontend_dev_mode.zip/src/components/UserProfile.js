const UserProfile = () => {
    return(
        <div className="container mx-auto bg-cyan-700 p-8 antialiased">
            <h1 className="text-3xl font-semibold text-center text-gray-800 capitalize lg:text-4xl dark:text-white mb-1">User Profile</h1>
        </div>
    )
}

export default UserProfile;