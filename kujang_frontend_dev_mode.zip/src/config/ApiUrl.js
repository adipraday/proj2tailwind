const ApiUrl = {
  //API_BASE_URL: "http://127.0.0.1:5000", // local
  API_BASE_URL: "http://103.159.112.249:9002", // API Server
};

export default ApiUrl;
